﻿using System;

public class Estudiante
{
    // Propiedades
    string Nombre;
    int Edad;
    string Carrera;
    int Carnet;
    double NotaAdmision;

    // Constructor
    public Estudiante(string nombre, int edad, string carrera, int carnet, double notaAdmision)
    {
        this.Nombre = nombre;
        this.Edad = edad;
        this.Carrera = carrera;
        this.Carnet = carnet;
        this.NotaAdmision = notaAdmision;
    }
    public void MostrarResumen()
    {
        Console.WriteLine("Nombre: " + this.Nombre);
        Console.WriteLine("Edad: " + this.Edad);
        Console.WriteLine("Carrera: " + this.Carrera);
        Console.WriteLine("Carnet: " + this.Carnet);
        Console.WriteLine("Nota de Admisión: " + this.NotaAdmision);
    }
    public bool PuedeMatricular()
    {
        return NotaAdmision >= 75 && Carnet.ToString().EndsWith("2025");
    }
}

public class Program
{
    public static void Main()
    {
        // Captura de datos desde la consola
        Console.Write("Nombre: ");
        string nombre = Console.ReadLine();

        Console.Write("Edad: ");
        int edad = int.Parse(Console.ReadLine());

        Console.Write("Carrera: ");
        string carrera = Console.ReadLine();

        Console.Write("Carnet: ");
        int carnet = int.Parse(Console.ReadLine());

        Console.Write("Nota de Admisión: ");
        double notaAdmision = double.Parse(Console.ReadLine());

        // Crear objeto Estudiante
        Estudiante estudiante = new Estudiante(nombre, edad, carrera, carnet, notaAdmision);

        // Mostrar resumen del estudiante
        Console.WriteLine("\n--- Resumen del Estudiante ---");
        estudiante.MostrarResumen();

        // Verificar si puede matricularse
        if (estudiante.PuedeMatricular())
        {
            Console.WriteLine("\n¡El estudiante puede matricularse!");
        }
        else
        {
            Console.WriteLine("\nEl estudiante no cumple las condiciones para matricularse.");
        }
    }
}